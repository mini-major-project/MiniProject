package onRoadBreakDown_MiniProject;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServiceProviderRegistration
 */
@WebServlet("/ServiceProviderRegistration")
public class ServiceProviderRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ServiceProviderRegistration() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out = response.getWriter();

		String serviceProviderMail = request.getParameter("serviceProviderMail");
		String serviceProviderPswd = request.getParameter("serviceProviderPswd");
		String serviceProviderPswd2 = request.getParameter("serviceProviderPswd2");
		String serviceProviderName = request.getParameter("serviceProviderName");
		String serviceProviderAddress = request.getParameter("serviceProviderAddress");
		String serviceProviderPinCode = request.getParameter("serviceProviderPinCode");
		String serviceProviderMobile = request.getParameter("serviceProviderMobile");

		String MechAsst = "";
		String BatRepl = "";
		String TyreRepl = "";
		String VechTow = "";
		String FuelRef = "";
		String Servicing = "";
		System.out.println("sern: " +request.getParameter("MechAsst") );
		if (request.getParameter("MechAsst")!=null ) {
			MechAsst = "YES";
		} else {
			MechAsst = "NO";
		}
		if (request.getParameter("BatRepl")!=null) {
			BatRepl = "YES";
		} else {
			BatRepl = "NO";
		}
		
		if (request.getParameter("TyreRepl")!=null ) {
			TyreRepl = "YES";
		} else {
			TyreRepl = "NO";
		}
		if (request.getParameter("VechTow")!=null) {
			VechTow = "YES";
		} else {
			VechTow = "NO";
		}
		if (request.getParameter("FuelRef")!=null ) {
			FuelRef = "YES";
		} else {
			FuelRef = "NO";
		}
		if (request.getParameter("Servicing")!=null ) {
			Servicing = "YES";
		} else {
			Servicing = "NO";
		}
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/onRoadBreakDown", "root",
					"Manasa123");
			PreparedStatement pstmt = con.prepareStatement(
					"insert into serviceProvider(serviceProviderName,serviceProviderPswd,serviceProviderAddress,serviceProviderMobile,serviceProviderMail,serviceProviderPinCode,MechAsst,BatRepl,TyreRepl,VechTow,FuelRef,Servicing) values(?,?,?,?,?,?,?,?,?,?,?,?);");
			pstmt.setString(1, serviceProviderName);
			pstmt.setString(2, serviceProviderPswd);
			pstmt.setString(3, serviceProviderAddress);
			pstmt.setString(4, serviceProviderMobile);
			pstmt.setString(5, serviceProviderMail);
			pstmt.setString(6, serviceProviderPinCode);
			// MechAsst,BatRepl,TyreRepl,VechTow,FuelRef,Servicing
			pstmt.setString(7, MechAsst);
			pstmt.setString(8, BatRepl);
			pstmt.setString(9, TyreRepl);
			pstmt.setString(10, VechTow);
			pstmt.setString(11, FuelRef);
			pstmt.setString(12, Servicing);

			int rs = pstmt.executeUpdate();
			if (rs > 0) {
				System.out.println("Registered Successfully");
				RequestDispatcher rd = request.getRequestDispatcher("ServiceProviderLogin.html");
				rd.forward(request, response);
			} else {
				System.out.print("Error");
			}
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
