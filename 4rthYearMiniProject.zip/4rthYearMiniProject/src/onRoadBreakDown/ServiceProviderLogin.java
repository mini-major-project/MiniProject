package onRoadBreakDown;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ServiceProviderLogin
 */
@WebServlet("/ServiceProviderLogin")
public class ServiceProviderLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServiceProviderLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String serviceProviderMail = request.getParameter("serviceProviderMail");
		String serviceProviderPswd = request.getParameter("serviceProviderPswd");
		PrintWriter out = response.getWriter();

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/OnRoadBreakDown", "root", "Taraka123");
			PreparedStatement pstmt = con.prepareStatement("select * from serviceProvider where serviceProviderMail=?");
			pstmt.setString(1, serviceProviderMail);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next() == false) {
				System.out.println("First Register");
				RequestDispatcher rd = request.getRequestDispatcher("ServiceProviderRegisteration.html");
				rd.include(request, response);
			} else {
				String pswd = "";
				String serviceProviderMobile = "";
				String serviceProviderName="";
				String serviceProviderId="";
				do {
					pswd = rs.getString("userPswd");
					serviceProviderMobile = rs.getString("userMobile");
					serviceProviderName=rs.getString("userName");
					serviceProviderId=rs.getString("userId");
				} while (rs.next());
				if (serviceProviderPswd.equals(pswd)) {
					System.out.println("Login Successful");
					HttpSession session = request.getSession();
					session.setAttribute("userMail", serviceProviderMail);
					session.setAttribute("userMobile", serviceProviderMobile);
					session.setAttribute("userName", serviceProviderName);
					session.setAttribute("userId", serviceProviderId);

					RequestDispatcher rd = request.getRequestDispatcher("home.html");
					rd.forward(request, response);
				} else {
					System.out.println("Wrong Password");
					out.println("Wrong password has entered. Please enter the correct password.");
					RequestDispatcher rd = request.getRequestDispatcher("ServiceProviderLogin.html");
					rd.include(request, response);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
